# Clawd — idle and punch study

Open `index.html` in a browser to preview. The preview works offline; keep
`preview-data.js` beside it. Use Idle / Punch, pause, frame stepping, playback
speed, previous-frame overlay, and light/dark/checkerboard backgrounds.

## Editable source

Open `clawd.aseprite` in Aseprite. The timeline contains:

- **idle:** frames 1–6, looping, 810 ms.
- **punch:** frames 7–15, 659 ms; return to idle after playing once.
- Frame 11 is the contact pose. This is an animation timing study, not balanced
  fighting-game frame data. No gameplay hitboxes are assigned.

Eight editable image layers: four feet, punch forearm, body, left hand, right
hand. Each layer has a full RGBA cel on every frame. Transparent forearm cels
are intentional when the arm is not extending. Refine cels directly, or draw
new poses on additional layers. The `origin` slice marks the fixed pivot.

## Exports

- `clawd-master.png`: neutral pose on the full frame canvas.
- `clawd-sheet.png`: 5 columns × 3 rows, 15 frames in reading order.
- `clawd-sheet.json`: Aseprite-style JSON array atlas with frame durations,
  `idle` / `punch` tags, and the origin slice.
- `clawd-moves.json`: explicit animation transitions and phase labels for the
  browser prototype. Indices here and in JSON are zero-based.
- `frames/`: individual numbered PNGs.
- `parts/`: normalized body and limb source PNGs.

Every frame is **224 × 160**, with no trimming or padding between cells.
The world origin is **(106,136)**. Neutral visible height is **118 pixels**.
Use nearest-neighbor scaling and disable texture smoothing. The same 12 opaque
colours and binary transparency are used throughout. The PNG atlas is
1120 × 480. Keep the complete canvas to prevent pivot jitter.

Use the JSON frame rectangles and durations to play these in the browser game.
Configure idle to repeat and return to idle when punch finishes; the preview
implements those transitions directly without a game engine.

## How this was made and checked

The built-in image generator produced separated source artwork based on the
approved Clawd concept. Assembly reduced that artwork to a fixed pixel grid and
shared palette. Body and limb cels were positioned to create the idle and punch;
the punch also stretches a separate forearm cel behind the fist. These are
reusable-part animations, not 15 independently hand-drawn poses.

The same master cel is used at idle start/end and punch start/end. All feet
stay at y=136, and all artwork fits inside the frame. An independent decoder
recomposited all eight Aseprite layers for every frame and checked exact pixel
equality against the PNG atlas and individual PNGs. Results: `verification.json`.

Aseprite was not installed on this machine, so the file has not yet been opened
in Aseprite itself. It was encoded against the documented file format:
https://github.com/aseprite/aseprite/blob/main/docs/ase-file-specs.md

## Rebuilding

Workspace scripts: `scripts/build-clawd.cjs` (Node + sharp) and
`scripts/verify-clawd.py` (Python + Pillow). The downloadable ZIP also includes
these under `scripts/`; pass the asset folder as the first argument there.

After editing in Aseprite, re-export the PNG + JSON for the game. The browser
preview embeds a snapshot in `preview-data.js`; it does not automatically read
later Aseprite edits. Update that embedded data or integrate the exported atlas
into the game to preview subsequent edits.
