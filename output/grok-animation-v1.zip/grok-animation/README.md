# Grok — first sprite-sheet pass

42 frames, seven animations. Sprite assets only; no game files were changed.

* `grok-sheet.png`: transparent 1344 × 1120 atlas, six columns and seven rows.
* `grok-sheet.json`: frame rectangles, durations, and animation tags.
* `grok-moves.json`: origin, loop/return/hold metadata. Art timing only.
* `grok.ase` / `grok.aseprite`: editable timeline with seven named tags.
* `strips/`: one transparent six-frame PNG strip per animation.
* `frames/`: 42 individual PNG cels; `grok-master.png` is the neutral pose.

Every cel is 224 × 160. Anchor at (106,136), facing right. Use nearest-neighbor
scaling. Keep the full canvas to preserve the pivot. Black/charcoal is the
default; colour changes accompany transformations.

| Row | Tag | Frames (zero-based) | Action |
| --- | --- | --- | --- |
| 1 | idle | 0–5 | Breathe and blink; loop |
| 2 | punch | 6–11 | Red capsule body punch; return to idle |
| 3 | uppercut | 12–17 | Orange teardrop into rising triangle |
| 4 | kick | 18–23 | Blue square body strike; no literal leg |
| 5 | damage | 24–29 | Recoil, squeezed eyes, recover |
| 6 | victory | 30–35 | Happy eyes across coloured shapes; loop |
| 7 | defeated | 36–41 | Dazed eyes, deflate; hold final cel |

This is a first animation pass using generated key poses, not hand-drawn
in-between animation. It uses one editable artwork layer; the eyes are not
separate layers. Neutral poses and loop/hold endpoints reuse identical cels
to prevent seam drift. Further timing and in-between refinements can be made
in LibreSprite or Aseprite.

Source artwork was created with the built-in image-generation tool using the
supplied Grok shape/colour reference and Clawd rendering reference. The exact
prompt is in `source/generation-prompt.txt`; the untouched source is
`source/generated-sheet.png`. Packing applies nearest-neighbor scaling,
palette normalization, binary alpha, and fixed-canvas alignment.

`verification.json` records pixel equality between all 42 exported editable
cels and atlas crops. Neither editor was opened for application-level checking.
The JSON files, rather than editor tag settings, specify loop/hold behavior.
